#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sqlite3
from datetime import datetime

class db_operator(object):
    def db_connect(self):
        self.handler = sqlite3.connect('../db/irrigation.db', check_same_thread = False)
        self.select_cur = self.handler.cursor()
        self.update_cur = self.handler.cursor()
        self.insert_cur = self.handler.cursor()
        return self.handler, self.select_cur, self.update_cur, self.insert_cur
    
    def db_init(self):
        with open('../db/db_creater_02_.sql','r') as f:
            sql_str = f.read()
        self.handler.executescript(sql_str)
        self.handler.commit()
    
    ################################################################### 
    def db_insert_data(self, data):
        ''' data:
                node_id
                sensor_id
                data
        '''
        sql_str = '''
                    insert into tb_history_data(
                                                node_id, 
                                                sensor_id, 
                                                data, 
                                                insert_time) 
                    values(?, ?, ?, ?)
                '''
        now_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.insert_cur.execute( sql_str, [data.node_id, \
                                   data.sensor_id, \
                                   data.data, \
                                   now_time])
        self.handler.commit()
        
    def db_insert_task(self, task):
        ''' task:
                transaction_number
                node_id
                sensor_id
                operation_code
                operation_data
                status
        '''
        str_sql = '''
                    insert into tb_task(
                                                transaction_number, 
                                                insert_time, 
                                                node_id, 
                                                sensor_id, 
                                                operation_code, 
                                                operation_data, 
                                                status)
                    values(?, ?, ?, ?, ?, ?, ?)
                '''
        operating_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.insert_cur.execute(str_sql, [task.transaction_number, \
                                   operating_time, \
                                   task.node_id, \
                                   task.sensor_id, \
                                   task.operation_code, \
                                   task.operation_data, \
                                   task.status])
        self.handler.commit()
    
    ###################################################################
    def db_select_task_status(self, task):
        ''' task:
                transaction_number
        '''
        str_sql = '''
                    select  node_id, status from tb_task
                        where transaction_number = ? 
                '''
        result = self.select_cur.execute(str_sql, [task.transaction_number])
        return result
    
    def db_select_task(self, task):
        ''' task:
                transaction_number
                status
        '''
        str_sql = '''
                    select  transaction_number,
                            node_id,
                            sensor_id, 
                            operation_code, 
                            operation_data,
                            status,
                            insert_time
                    from tb_task
                        where status = ?
                '''
        result = self.select_cur.execute(str_sql, [task.status])
        return result
    
    def db_select_realtime_data(self, data):
        ''' data:
                node_id       
        '''
        str_sql = '''
                    select node_id, sensor_id, data, insert_time from tb_realtime_data 
                        where node_id = ? 
                '''
        result = self.select_cur.execute(str_sql, [data.node_id])
        return result
    
    def db_select_history_data(self, data):
        ''' data:
                 node_id
                 start_time
                 end_time
         '''
        str_sql = '''
                     select node_id, sensor_id, data, insert_time from tb_history_data
                         where node_id = ? and insert_time between ? and ? 
                         order by insert_time
                 '''
        result = self.select_cur.execute(str_sql, [data.node_id, data.start_time, data.end_time])
        return result
    
    def db_select_all_history_data(self, condition):
        ''' condition:
                node_id
        '''
        str_sql = '''
                     select node_id, sensor_id, data, insert_time from tb_history_data
                         where node_id = ?
                         order by insert_time
                 '''
        result = self.select_cur.execute(str_sql, [condition.node_id])
        return result
    
    def db_select_sensor_state(self, condition):
        '''condition:
                node_id
        '''
        str_sql = '''
                     select node_id ,sensor_id, switcher, capture_frequency, threshold from tb_sensor_state
                     where node_id = ?
                 '''
        result = self.select_cur.execute(str_sql, [condition.node_id])
        return result
    ###################################################################
    def db_update_task(self, condition):
        '''condition:
                transaction_number
                status
        '''
        str_sql = '''
                    update tb_task
                    set status = ?
                    where transaction_number = ?
                '''
        result = self.update_cur.execute(str_sql, [condition.status, condition.transaction_number])
        self.handler.commit()
        return result
    
    def db_update_sensor_state(self, condition):
        '''condition:
                node_id
                sensor_id
                switcher
                capture_frequency
                threshold
        '''
        str_sql = '''
                    update tb_sensor_state
                    set switcher = ?, 
                        capture_frequency = ?,
                        threshold = ?
                    where node_id = ? and sensor_id = ?
                '''
        result = self.update_cur.execute(str_sql, [condition.switcher, \
                                            condition.capture_frequency, \
                                            condition.threshold, \
                                            condition.node_id, \
                                            condition.sensor_id])
        self.handler.commit()
        return result
    
    ###################################################################
    def db_close(self):
        self.handler.close() 
#######################
db_op = db_operator()
#######################

command_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class t_insert_data():
        node_id = 3
        sensor_id = 3
        data = 3
        
class t_select_sensor_state():
    node_id = 3

class t_update_sensor_state():
        node_id = 1
        sensor_id = 2
        switcher = 2
        capture_frequency = 2
        threshold = 4

class t_select_history_data():
    node_id = 3
    start_time = '2013-06-05 10:28:21' 
    end_time = command_time
    


class t_insert_task():
    transaction_number = command_time
    node_id = 6
    sensor_id = 5
    operation_code = 1
    operation_data = 1
    status = 1
    
class t_select_task_status():
    transaction_number = command_time

class t_select_task():
    status = 3


class t_update_task():
    transaction_number = ''
    status = 3

def main():
    ############################ Testing Data #######################################
    insert_data = t_insert_data()
    select_sensor_state = t_select_sensor_state()
    update_sensor_state = t_update_sensor_state()
    condition_select_history_data = t_select_history_data()
    insert_task = t_insert_task()
    select_task_status = t_select_task_status()
    select_task = t_select_task()
    select_all_history_data = select_sensor_state
    
    update_task = t_update_task()
    update_task.transaction_number = command_time
    update_task.status = 1
    ################################################################################
    
    db = db_operator()
    db.db_connect()
    try:
        db.db_init()
    except sqlite3.OperationalError, e:
        print e
    try:
        db.db_insert_data(insert_data)
        db.db_insert_task(insert_task)
        db.db_update_sensor_state(update_sensor_state)
        db.db_update_task(update_task)
        
        result2 = db.db_select_realtime_data(select_sensor_state)
        print 'realtime data: %r' % result2.fetchall()
        
        result3 = db.db_select_sensor_state(select_sensor_state)
        print 'sensor  state: %r' % result3.fetchall()
        
        result1 = db.db_select_history_data(condition_select_history_data)
        print 'history  data: %r' % result1.fetchall()
        
        result5 = db.db_select_task(select_task)
        print 'task     data: %r' % result5.fetchall()
    
        result6 = db.db_select_task_status(select_task_status)
        print 'task   status: %r' % result6.fetchall()
        
        result7 = db.db_select_all_history_data(select_all_history_data)
        print 'all history data: %r' %result7.fetchall()
    
    finally:
        db.db_close()
    
if __name__ == '__main__': 
    main()