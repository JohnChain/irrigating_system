
-- Table: tb_node
CREATE TABLE tb_node ( 
    node_id     INTEGER  PRIMARY KEY ON CONFLICT IGNORE
                         NOT NULL
                         UNIQUE ON CONFLICT IGNORE,
    insert_time DATETIME NOT NULL,
    reserved1   INTEGER,
    reserved2   INTEGER 
);

INSERT INTO [tb_node] ([node_id], [insert_time], [reserved1], [reserved2]) VALUES (3, '2013-06-05 13:44:54', null, null);

-- Table: tb_node_sensor
CREATE TABLE tb_node_sensor ( 
    node_id   INTEGER NOT NULL
                      REFERENCES tb_node ( node_id ) ON DELETE CASCADE,
    sensor_id INTEGER NOT NULL,
    remark    VARCHAR,
    PRIMARY KEY ( node_id, sensor_id )  ON CONFLICT IGNORE 
);

INSERT INTO [tb_node_sensor] ([node_id], [sensor_id], [remark]) VALUES (3, 3, null);

-- Table: tb_realtime
CREATE TABLE tb_realtime ( 
    node_id     INTEGER  NOT NULL
                         REFERENCES tb_node ( node_id ) ON DELETE CASCADE
                                                        ON UPDATE CASCADE,
    sensor_id   INTEGER  NOT NULL,
    data        REAL     NOT NULL
                         DEFAULT ( -1000 ),
    insert_time DATETIME NOT NULL,
    PRIMARY KEY ( node_id, sensor_id )  ON CONFLICT REPLACE 
);

INSERT INTO [tb_realtime] ([node_id], [sensor_id], [data], [insert_time]) VALUES (3, 3, 3.0, '2013-06-05 14:26:11');

-- Table: tb_record
CREATE TABLE tb_record ( 
    record_id   INTEGER  PRIMARY KEY AUTOINCREMENT
                         NOT NULL
                         UNIQUE,
    node_id     INTEGER  NOT NULL,
    sensor_id   INTEGER  NOT NULL,
    data        REAL     NOT NULL
                         DEFAULT ( -1000 ),
    insert_time DATETIME NOT NULL 
);

INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (1, 3, 3, 3.0, '2013-06-05 13:44:54');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (2, 3, 3, 3.0, '2013-06-05 13:45:10');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (3, 3, 3, 3.0, '2013-06-05 13:57:24');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (4, 3, 3, 3.0, '2013-06-05 13:58:05');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (5, 3, 3, 3.0, '2013-06-05 13:58:30');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (6, 3, 3, 3.0, '2013-06-05 13:59:04');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (7, 3, 3, 3.0, '2013-06-05 14:09:01');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (8, 3, 3, 3.0, '2013-06-05 14:11:10');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (9, 3, 3, 3.0, '2013-06-05 14:12:29');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (10, 3, 3, 3.0, '2013-06-05 14:15:53');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (11, 3, 3, 3.0, '2013-06-05 14:16:19');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (12, 3, 3, 3.0, '2013-06-05 14:21:02');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (13, 3, 3, 3.0, '2013-06-05 14:21:28');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (14, 3, 3, 3.0, '2013-06-05 14:21:55');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (15, 3, 3, 3.0, '2013-06-05 14:24:48');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (16, 3, 3, 3.0, '2013-06-05 14:25:56');
INSERT INTO [tb_record] ([record_id], [node_id], [sensor_id], [data], [insert_time]) VALUES (17, 3, 3, 3.0, '2013-06-05 14:26:11');

-- Table: tb_network
CREATE TABLE tb_network ( 
    node_id   INTEGER PRIMARY KEY ON CONFLICT REPLACE
                      NOT NULL
                      UNIQUE
                      REFERENCES tb_node ( node_id ) ON DELETE CASCADE
                                                     ON UPDATE CASCADE,
    parent_id INTEGER,
    quality   INTEGER 
);


-- Table: tb_feedback
CREATE TABLE tb_feedback ( 
    transaction_number VARCHAR          NOT NULL
                                        UNIQUE,
    insert_time        DATETIME         NOT NULL,
    node_id            INTEGER          NOT NULL,
    status             INTEGER( 0, 1 )  NOT NULL,
    remark             VARCHAR,
    reversed           INTEGER,
    PRIMARY KEY ( transaction_number, node_id, insert_time ) 
);

INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('hello world', '2013-06-05 14:09:01', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:15:53', '2013-06-05 14:15:53', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:16:19', '2013-06-05 14:16:19', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:21:02', '2013-06-05 14:21:02', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:21:28', '2013-06-05 14:21:28', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:21:55', '2013-06-05 14:21:55', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:24:48', '2013-06-05 14:24:48', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:25:56', '2013-06-05 14:25:56', 3, 1, null, null);
INSERT INTO [tb_feedback] ([transaction_number], [insert_time], [node_id], [status], [remark], [reversed]) VALUES ('2013-06-05 14:26:11', '2013-06-05 14:26:11', 3, 1, null, null);

-- Index: idx_tb_record
CREATE INDEX idx_tb_record ON tb_record ( 
    node_id,
    sensor_id,
    insert_time 
);


-- Index: idx_tb_node
CREATE INDEX idx_tb_node ON tb_node ( 
    node_id 
);


-- Index: idx_tb_feedback
CREATE UNIQUE INDEX idx_tb_feedback ON tb_feedback ( 
    transaction_number,
    insert_time 
);


-- Trigger: trg_record_insert_realtime
CREATE TRIGGER trg_record_insert_realtime
       AFTER INSERT ON tb_record
       FOR EACH ROW
BEGIN
    INSERT INTO tb_realtime VALUES ( 
        new.node_id,
        new.sensor_id,
        new.data,
        new.insert_time 
    );
END;
;


-- Trigger: trg_record_insert_node
CREATE TRIGGER trg_record_insert_node
       BEFORE INSERT ON tb_record
       FOR EACH ROW
BEGIN
    INSERT INTO tb_node ( 
        node_id,
        insert_time 
    ) 
    VALUES ( 
        new.node_id,
        new.insert_time 
    );

    INSERT INTO tb_node_sensor ( 
        node_id,
        sensor_id 
    ) 
    VALUES ( 
        new.node_id,
        new.sensor_id 
    );
END;
;

