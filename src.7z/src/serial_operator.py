#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from time import sleep
from task_manager import *
from db_operator import *

class serial_operator(object):
    task_to_send = []
    task_received = []
    def commit_task(self, db_op):
        update_task = t_update_task()
        update_task.status = DEALING
#     while True:
        print "\n---------start pick tasks out from the task_list...---------"
        for key in task_mag.task_dict.keys():
            if task_mag.task_dict[key][5] == SUBMITTING:
                task_mag.task_dict[key][5] = DEALING
                task_received = task_mag.task_dict[key][0:5]
                update_task.transaction_number = task_received[0]
                
                db_op.db_update_task(update_task)
                print "one task has been update to dealing..."
                task_received[0] = int(key)
                print "submitting one task..."
        print "---------now the task list is empty...---------"
#         print "---------we are going to sleep for one second...---------"
#         sleep(1)
        

##############################        
serial_op = serial_operator()
##############################

def test():
    serial_op = serial_operator()
    print "%r" %type(serial_op)
    hehe = serial_operator()

if __name__ == "__main__":
    test()