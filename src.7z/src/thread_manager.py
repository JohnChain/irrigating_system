#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import threading
from datetime import datetime
from task_manager import *
from db_operator import *
from serial_operator import *

class MyThread(threading.Thread): 
    def __init__(self, func, args, name=''): 
        threading.Thread.__init__(self) 
        self.name = name 
        self.func = func 
        self.args = args 
    
    def getResult(self): 
        return self.res 
    
    def run(self): 
        print 'starting', self.name, 'at:',  
        self.res = apply(self.func, self.args)
        print self.name, 'finished at:', datetime.now()

class thread_manager(object):
    thread_list = []
    def downword(self):
        print "############ Now we are in downword thread ################"
        db_op = db_operator()
        db_op.db_connect()
        while True:
            task_mag.build_dict(db_op)
            serial_op.commit_task(db_op)
        db_op.db_close()
     
    def upword(self):
        print "############ Now we are in upword thread ################"
        db_op = db_operator()
        db_op.db_connect()
        update_task = t_update_task()
        update_task.status = FAILED
        while True: 
            print "\n---------start exchange task id and remove task from the task_list...---------"
            for key in task_mag.task_dict.keys():
                update_task.transaction_number = task_mag.exchange_task_id(key)
                print "exchange one and update one"
                db_op.db_update_task(update_task)
            print "---------now the task list is empty...---------"
#             sleep(1)
        db_op.db_close()
            
    def init_thread_list(self):
        self.thread_list.append( MyThread(self.downword,(),self.downword.__name__) )
        self.thread_list.append( MyThread(self.upword,(),self.upword.__name__) )
    
    def start_thread(self):
        thread_num = len(self.thread_list)
        for i in range(thread_num):
            self.thread_list[i].start()
#             sleep(1)
    
thread_mag = thread_manager()
def test_thread_manager():
#     try:
#         db_op.db_connect()
#         db_op.db_init()
#     except sqlite3.OperationalError, e:
#         print e
#      
#     try:
    thread_mag.init_thread_list()
    thread_mag.start_thread()
    thread_mag.thread_list[0].join()
    thread_mag.thread_list[1].join()
#     except Exception, e:
#         print e
#     finally:
#     db_op.db_close()

if __name__ =='__main__':
    test_thread_manager()
    