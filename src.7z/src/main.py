#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import threading
import thread
from time import sleep 
from datetime import datetime

rlock_command_list =  threading.RLock()
lock_command_list = thread.allocate_lock()

command_message = {
                   "NUM": 0,
                   "command": "kill",
                   }

command_list = []
class MyThread(threading.Thread): 
    def __init__(self, func, args, name=''): 
        threading.Thread.__init__(self) 
        self.name = name 
        self.func = func 
        self.args = args 
    
    def getResult(self): 
        return self.res 
    
    def run(self): 
        print 'starting', self.name, 'at:',  
        self.res = apply(self.func, self.args)
        print self.name, 'finished at:', datetime.now()

def read_device():
    while True:
        print "\nreading device"
        sleep(1)
    
def read_command():
    global command_list
    while True:
        print "\nReading command..."
        rlock_command_list.acquire()
        command_message['NUM'] += 1
        command_list.append(command_message)
        print "One command appended to command list"
        rlock_command_list.release()
        sleep(0.005)
    
def send_command():
    global command_list
    while True:
        rlock_command_list.acquire()
        if command_list.__len__() > 0:
            print "\ncurrent command list length is : %d" %command_list.__len__()
            print "Sending command: NUM = %d   command = %s" %(command_list[0]['NUM'],command_list[0]['command'])
            command_list.remove(command_list[0])
        else:
            print "\nEmpty command list!!!"
        rlock_command_list.release()
        sleep(0.05)

def main():
    thread_list = []

    thread_list.append( MyThread(read_device,(),read_device.__name__) )
    thread_list.append( MyThread(read_command,(),read_command.__name__) )
    thread_list.append( MyThread(send_command,(),send_command.__name__) )
    
    thread_list[0].start()
    thread_list[1].start()
    thread_list[2].start()
    
if __name__ == '__main__': 
    main()