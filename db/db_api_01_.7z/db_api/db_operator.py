#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import sqlite3
from datetime import datetime

class db_operator(object):
    def db_connect(self):
#         self.handler = sqlite3.connect('c:/users/johnchain/desktop/irrigating_system/irrigation.db')
        self.handler = sqlite3.connect('irrigation.db')
        self.cur = self.handler.cursor()
        return self.handler, self.cur
    
    def db_init(self):
        with open('db_creater.sql','r') as f:
            sql_str = f.read()
        self.handler.executescript(sql_str)
        self.handler.commit()
        
    def db_insert_data(self, data):
        ''' data:
                node_id
                sensor_id
                data
        '''
        sql_str = '''
                    insert into tb_record(node_id, sensor_id, data, insert_time) 
                    values(?, ?, ?, ?)
                '''
        now_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cur.execute( sql_str, [data.node_id, data.sensor_id, data.data, now_time])
        self.handler.commit()
    def db_insert_feedback(self, feedback):
        ''' feedback:
                transaction_number
                insert_time
                node_id
                status
        '''
        str_sql = '''
        insert into tb_feedback(transaction_number, insert_time, node_id, status)
        values(?, ?, ?, ?)
        '''
        self.cur.execute(str_sql, [feedback.transaction_number, feedback.insert_time, feedback.node_id, feedback.status])
        self.handler.commit()
    
    def db_select_feedback(self, feedback):
        ''' feedback:
                transaction_number
        '''
        str_sql = '''
        select  node_id, status from tb_feedback
            where transaction_number = ? 
        '''
        result = self.cur.execute(str_sql, [feedback.transaction_number])
        return result
    
    def db_select_realtime(self, data):
        ''' data:
                node_id
                sensor_id        
        '''
        str_sql = '''
        select node_id, sensor_id, data, insert_time from tb_realtime 
            where node_id = ? and sensor_id = ? 
        '''
        result = self.cur.execute(str_sql, [data.node_id, data.sensor_id])
        return result
    
    def db_select_parttime(self, data):
        ''' data:
                 node_id
                 sensor_id
                 start_time
                 end_time
         '''
        str_sql = '''
         select node_id, sensor_id, data, insert_time from tb_record
             where node_id = ? and sensor_id = ? and insert_time between ? and ? 
             order by insert_time
         '''
        result = self.cur.execute(str_sql, [data.node_id, data.sensor_id, data.start_time, data.end_time])
        return result
    
    def db_close(self):
        self.handler.close() 
    
def main():
    ############################ exemple data #######################################
    class data0():
        node_id = 3
        sensor_id = 3
        data = 3
        
    class data1():
        node_id = 3
        sensor_id = 3
        
    class data2():
        node_id = 3
        sensor_id = 3
        start_time = '2013-06-05 10:28:21' 
        end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
    command_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    class feedback_insert():
        transaction_number = command_time
        insert_time = command_time
        node_id = 3
        status = 1
    
    class feedback_select():
        transaction_number = command_time
        
    ###################################################################
    
    db = db_operator()
    db.db_connect()
    try:
        db.db_init()
    except sqlite3.OperationalError, e:
        print e
    
    db.db_insert_data(data0)
    db.db_insert_feedback(feedback_insert)
    
    result1 = db.db_select_parttime(data2)
    print 'parttime data: %r' % result1.fetchall()
    result2 = db.db_select_realtime(data1)
    print 'realtime data: %r' % result2.fetchall()
    result3 = db.cur.execute('select * from tb_node')
    print 'tb_node  info: %r' % result3.fetchall()
    result5 = db.db_select_feedback(feedback_select)
    print 'feedback data: %r' % result5.fetchall()

    db.db_close()
    
if __name__ == '__main__': 
    main()